from gtts import gTTS
import os
import tkinter as tk
from tkinter import filedialog, scrolledtext, ttk

def text_to_speech(text, language='en', output_file='output.mp3'):
    tts = gTTS(text=text, lang=language, slow=False)
    tts.save(output_file)

def play_audio(file_path):
    os.system(f'start {file_path}')

def convert_file_to_speech(file_path, language_code_var, progress_var):
    try:
        with open(file_path, 'r', encoding='utf-8') as file:
            file_content = file.read()

        language_code = language_code_var.get()
        text_to_speech(file_content, language=language_code)
        print(f"Text-to-speech conversion completed. Audio saved to output.mp3")
        play_audio('output.mp3')
        progress_var.set(100)
    except Exception as e:
        print(f"Error: {e}")

def browse_file(entry_var, text_box, progress_var):
    file_path = filedialog.askopenfilename(filetypes=[("Text files", "*.txt")])
    if file_path:
        entry_var.set(file_path)
        with open(file_path, 'r', encoding='utf-8') as file:
            content = file.read()
        text_box.delete("1.0", tk.END)
        text_box.insert(tk.END, content)
        progress_var.set(0)

if __name__ == "__main__":
    root = tk.Tk()
    root.title("Text to Speech Converter")

    file_path_var = tk.StringVar()
    language_code_var = tk.StringVar()
    language_code_var.set('en')

    label1 = tk.Label(root, text="Select a text file for text-to-speech conversion:")
    label1.pack(pady=10)

    entry = tk.Entry(root, textvariable=file_path_var, width=40)
    entry.pack(pady=5)

    browse_button = tk.Button(root, text="Browse", command=lambda: browse_file(file_path_var, text_box, progress_var))
    browse_button.pack(pady=5)

    label2 = tk.Label(root, text="Language Code (default is 'en' for English):")
    label2.pack(pady=5)

    language_entry = tk.Entry(root, textvariable=language_code_var, width=40)
    language_entry.pack(pady=5)

    text_box = scrolledtext.ScrolledText(root, wrap=tk.WORD, width=40, height=10)
    text_box.pack(pady=10)

    convert_button = tk.Button(root, text="Convert to Speech", command=lambda: convert_file_to_speech(
        file_path_var.get(), language_code_var, progress_var))
    convert_button.pack(pady=5)

    progress_var = tk.DoubleVar()
    progress_bar = ttk.Progressbar(root, variable=progress_var, length=200, mode='determinate')
    progress_bar.pack(pady=10)

    root.mainloop()
