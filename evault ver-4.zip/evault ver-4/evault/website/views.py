from django.shortcuts import redirect, render
from django.http import HttpResponse
from django.contrib.auth.models import User
from django.contrib.auth import authenticate, login as d_login
from django.contrib import messages
from django.core.mail import send_mail
import pymongo
from datetime import datetime
from .models import Person
import uuid
import random
from django.utils import timezone
from datetime import timedelta

client = pymongo.MongoClient()
db = client['myDb']
col = db['Files']
lawyer_db = db['lawyers']

def login(request):
    global username
    global name
    if request.method == "POST":
        username = request.POST['name']
        password = request.POST['password']
        user = authenticate(username=username, password=password)
        if user:
            temp = Person.objects.filter(UID=username)[0].name
            name = temp[0].upper() + temp[1:].lower()
            email = Person.objects.filter(UID=username)[0].email
            send_mail('Account Logged in',f'You are now signed into your Evault account.Please disregard if it is you; if not, report the incident by sending an email to ragav2706@gmail.com. ','anuragav754@gmail.com',[email],fail_silently=True)
            d_login(request,user)
            role = Person.objects.filter(email=email)[0].role
            return redirect("/home/?name={}&uid={}&role={}".format(name,username,role))
        else:
            messages.info(request,"Wrong Credentials")
            return redirect('/login')
    return render(request, 'website/login.html')

def signup(request):
    global email
    global username
    if request.method == "POST":
        name = request.POST['name']
        email = request.POST['mail']
        password = request.POST['password']
        age = request.POST['age']
        contact = request.POST['contact']
        if User.objects.filter(email=email).count() > 0:
            messages.error(request,"User Already Exists")
        else:
            name = name[0].upper() + name[1:].lower()
            unique_id = 'C' + uuid.uuid4().hex.upper()[:9]
            username=unique_id
            user = User.objects.create_user(username=unique_id,email=email, password=password)
            user.save()  
            temp = Person(name=name,email=email,age=age,contact=contact,UID =unique_id )
            temp.save()
            send_mail('Account Created Successfully',f'We are excited for your journey with us! Expect tailored updates, exclusive content, and dedicated support. '+str(unique_id),'anuragav754@gmail.com',[email],fail_silently=True)
            return redirect("/home/?name={}&uid={}".format(name,unique_id))
    return render(request, 'website/signup.html')

def forgot_password(request):
    if request.method == "POST" and 'form1' in request.POST:
        email = request.POST['email']
        OTP = random.randint(100000, 999999)
        send_mail('Reset Password',f' We heard that you lost your Vault password. Sorry about that.But don’t worry! You can use the following OTP to reset your password: '+str(OTP)+"This OTP is valid only for 5 mintues",'anuragav754@gmail.com',[email],fail_silently=False)
        expiration_time = timezone.now() + timedelta(minutes=5)
    elif request.method=="POST" and 'form2' in request.POST :
        user_otp = request.POST['otp']
        if user_otp == OTP and timezone.now() <= expiration_time:
            return HttpResponse("OTP is valid.")
        else:
            return HttpResponse("OTP is invalid or has expired.")
        # return redirect("/login")
    return render(request,'website/forgot_password.html')    

def home(request):
    role = Person.objects.filter(UID=username)[0].role
    if role=="citizen":
        filter_query = {"$or": [{"peti_id": username}, {"defen_id":username}]}
    elif role=="lawyer":
        filter_query = {"lawyer_id":username}
    result = col.find(filter_query)
    print(result)
    if request.method=="POST":
        key = request.POST['key']
        findings= lawyer_db.find({"location":key})
        global f
        f=[]
        for i in findings:
            a={}
            a['name']=i['name']
            a['age']=i['age']
            a['contact']=i['contact']
            a['experience']=i['experience']
            a['expertise']=i['expertise']
            a['total_cases']=i['total_cases']
            a['number_of_cases_accuted']=i['number_of_cases_accuted']
            a['location_url']=i['location_url']
            a['rating']=i['rating']
            a['email']=i['email'] 
            f.append(a)
        # return redirect('/lawyer',lawyer,data=f)
        return redirect("/lawyer")
    return render(request,"website/home.html",{'result':result})

def existingupload(request):
    return render(request,"website/existingupload.html")

def upload(request):
    min_date = f"{datetime.now().date().year}-{datetime.now().date().month:02d}-{datetime.now().date().day}"
    largest_filing_number_document = col.find_one(sort=[('filing_number', -1)])
    filing_number = largest_filing_number_document['filing_number'] +1
    print(filing_number)
    if request.method == "POST":
        case_type = request.POST.get('case_type',False)
        peti_id = request.POST['petitioner']
        defen_id = request.POST['defendant']
        jurisdiction = request.POST['jurisdiction']
        case_file = request.FILES.get('case_file')
        status="Filing"
        d1 ={}
        d1['case_type'] = case_type
        d1['filing_number'] = filing_number
        d1['filing_date'] = datetime.now()
        d1['peti_id'] = peti_id
        d1['defen_id']  = defen_id
        d1['court']  = jurisdiction
        d1['status']  = status
        d1['file']  = case_file
        d1['peti_lawyer'] = username
        d1['case_id'] = 0
        col.insert_one(d1)
        # defen_email = Person.objects.filter(UID=defen_id)[0].email
        # send_mail('New Case',f'There is a new case filed upon you. Click here for more information ','anuragav754@gmail.com',[defen_email],fail_silently=False)
        return redirect('/home/?name={}&uid={}&role={}'.format(name,username,"lawyer"))
    return render(request,"website/upload.html",{'min_date':min_date})

def lawyer(request):
    return render(request,"website/lawyers.html",{'data':f})

def homeright(request):
    caseid=request.GET['caseid']
    rec=0
    if caseid !=0:
            rec = col.find({'case_id':caseid})
    return render(request,"website/homeright.html",{'caseid':caseid,'rec':rec})