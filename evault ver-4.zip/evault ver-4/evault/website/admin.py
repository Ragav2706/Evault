from django.contrib import admin
from .models import Person,lawyer_detail
# Register your models here.
admin.site.register(Person)
admin.site.register(lawyer_detail)
