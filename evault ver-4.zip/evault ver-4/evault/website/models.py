from django.db import models
from django.core.validators import MaxValueValidator, MinValueValidator

class Person(models.Model):
    name = models.CharField(max_length=255)
    email = models.EmailField(null=True)
    age = models.IntegerField()
    contact = models.IntegerField()
    UID = models.CharField(max_length=15)
    role = models.CharField(max_length=15,default="citizen")
    def __str__(self):
        return self.name
        
lawyer_expertise=(
    ('CRL','Criminal Lawyer'),
    ('CIL','Civil Lawyer'),
    ('FL','Family Lawyer'),
    ('COL','Corporate Lawyer'),
    ('RL','Real Estate Lawyer'),
    ('EML','Employment Lawyer'),
    ('CL','Constitutional Lawyer'),
    ('TL','Tax Lawyer'),
    ('PL','Property Lawyer'),
    ('ENL','Environment Lawyer'),
    ('HRL','Human Rights Lawyer'),
    ('CPL','Consumer Protection Lawyer'),
    ('IL','Immigration Lawyer'),
    ('MML','Medical Malpractice Lawyer'),
    ('CLL','Cyber Law Lawyer'),
)
class lawyer_detail(models.Model):
    name = models.CharField(max_length=50)
    email = models.EmailField(null=True)
    photo  = models.ImageField(null=True)
    age = models.IntegerField()
    contact = models.IntegerField()
    expertise = models.CharField(max_length=50,choices=lawyer_expertise)
    experience = models.IntegerField()
    total_cases = models.IntegerField()
    number_of_accuted_cases = models.IntegerField()
    location = models.CharField(max_length=50,null=True)
    location_url = models.URLField(null=True)
    rating = models.IntegerField(validators=[MaxValueValidator(5),MinValueValidator(1)])
    def __str__(self) :
        return self.name






