from django.urls import path
from . import views
from django.conf.urls.static import static
from django.conf import settings

urlpatterns = [
    path('',views.login, name="login"),
    path('login/', views.login, name = "login"),
    path('signup/', views.signup, name = "signup"),
    path('home/',views.home,name="home"),
    path('upload/',views.upload,name="upload"),
    path('forgot_password/',views.forgot_password,name="forgot_password"),
    path('existingupload/',views.existingupload,name="existingupload"),
    path('lawyer/',views.lawyer,name="lawyer"),
    path('homeright/',views.homeright,name="homeright")

]